# Deb to IPA

An iOS app (for TrollStore) that turns jailbreak .deb packages containing an app into .ipa files, right on your device.

## Build the .ipa with GitHub (no Mac needed)

1. Create a new repository on github.com (private is fine).
2. Tap "uploading an existing file" and upload `DebToIPA-source.zip` as it is. Don't unzip it.
3. Tap "Add file" > "Create new file", name it `.github/workflows/build.yml`, paste the workflow text, and commit.
4. Open the "Actions" tab and wait for "Build Deb to IPA" to finish (about 3 to 5 minutes).
5. Open the finished run and download "DebToIPA-ipa" under Artifacts. Unzip it in the Files app.
6. Share `DebToIPA.ipa` to TrollStore to install.

(On a computer you can also upload the unzipped folder contents, including `.github`, instead.)

## Using the app

- Tap "Choose a .deb file", or share a .deb from Files or Safari to "Deb to IPA".
- When it's done, tap "Install with TrollStore…" and pick TrollStore in the share sheet.
- Converted files are kept under Files > On My iPhone > Deb to IPA > Converted.

## Limits

- Only packages that contain an app (`/Applications/*.app` or `/var/jb/Applications/*.app`) can be converted.
- Tweaks, libraries, themes and Linux packages are detected and refused with an explanation.
- Supported package compression: gzip, xz and uncompressed. Zstandard, bzip2 and legacy LZMA aren't supported yet.
- Apps made for jailbroken devices may still need jailbreak files and might not fully work after installing with TrollStore.
