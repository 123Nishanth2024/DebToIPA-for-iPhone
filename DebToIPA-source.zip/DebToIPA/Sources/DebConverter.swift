import Foundation

struct DebInfo {
    var package: String?
    var name: String?
    var version: String?
    var architecture: String?
}

struct ConvertedApp: Identifiable {
    let id = UUID()
    let name: String
    let bundleID: String?
    let version: String?
    let ipaURL: URL
    let sizeBytes: Int64
}

struct ConversionResult {
    let debInfo: DebInfo
    var apps: [ConvertedApp]
    let warnings: [String]
}

struct LibraryFile: Identifiable {
    let url: URL
    let size: Int64
    let modified: Date
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

enum DebConverter {
    /// Converted .ipa files are saved here. Visible in the Files app under "On My iPhone > Deb to IPA".
    static var outputDirectory: URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documents.appendingPathComponent("Converted", isDirectory: true)
    }

    static func convertFile(at url: URL) -> Result<ConversionResult, Error> {
        let scoped = url.startAccessingSecurityScopedResource()
        defer {
            if scoped { url.stopAccessingSecurityScopedResource() }
            // Files shared with "Copy to Deb to IPA" land in Documents/Inbox. Clean them up.
            if url.path.contains("/Documents/Inbox/") {
                try? FileManager.default.removeItem(at: url)
            }
        }
        do {
            return .success(try convert(debURL: url))
        } catch {
            return .failure(error)
        }
    }

    static func convert(debURL: URL) throws -> ConversionResult {
        let deb = try Data(contentsOf: debURL, options: .mappedIfSafe)
        let members = try ArArchive.parse(deb)
        guard members.contains(where: { $0.name == "debian-binary" }) else {
            throw ConversionError.notADeb
        }

        // 1. Read package details (optional, used for a clearer error on non-iOS packages).
        var info = DebInfo()
        if let control = members.first(where: { $0.name.hasPrefix("control.tar") }),
           let controlTar = try? Decompressor.decompress(control.data, fileName: control.name),
           let controlEntries = try? TarArchive.parse(controlTar),
           let controlFile = controlEntries.first(where: { $0.path == "control" && $0.kind == .file }) {
            info = parseControl(String(decoding: controlTar.subdata(in: controlFile.dataRange), as: UTF8.self))
        }

        if let architecture = info.architecture?.lowercased(),
           architecture != "all",
           !architecture.hasPrefix("iphoneos") {
            throw ConversionError.notIOS(architecture: architecture)
        }

        // 2. Unpack the package contents.
        guard let dataMember = members.first(where: { $0.name.hasPrefix("data.tar") }) else {
            throw ConversionError.missingData
        }
        let tar = try Decompressor.decompress(dataMember.data, fileName: dataMember.name)
        let entries = try TarArchive.parse(tar)

        // Later entries with the same path win, like when installing.
        var latest: [String: Int] = [:]
        for entry in entries {
            latest[entry.path] = entry.index
        }

        // 3. Find apps: ".../Applications/<Name>.app" (rootful) or "var/jb/Applications/<Name>.app" (rootless).
        var appRoots: [String] = []
        var seenRoots = Set<String>()
        for entry in entries {
            let parts = entry.path.split(separator: "/").map(String.init)
            for i in parts.indices where i > 0 && parts[i].hasSuffix(".app") && parts[i - 1] == "Applications" {
                let root = parts[0...i].joined(separator: "/")
                if seenRoots.insert(root).inserted {
                    appRoots.append(root)
                }
                break
            }
        }

        if appRoots.isEmpty {
            let isTweak = entries.contains { entry in
                let path = entry.path.lowercased()
                return path.contains("library/mobilesubstrate/dynamiclibraries/")
                    || path.contains("usr/lib/tweakinject/")
                    || path.contains("library/tweakinject/")
            }
            throw isTweak ? ConversionError.tweak : ConversionError.noApp
        }

        // 4. Build one .ipa per app.
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: outputDirectory, withIntermediateDirectories: true)

        var apps: [ConvertedApp] = []
        var warnings: [String] = []

        for root in appRoots {
            let folderName = root.split(separator: "/").last.map(String.init) ?? "App.app"
            let plist = readPlist(at: root + "/Info.plist", entries: entries, latest: latest, tar: tar)
            let executable = plist?["CFBundleExecutable"] as? String
            let displayName = (plist?["CFBundleDisplayName"] as? String)
                ?? (plist?["CFBundleName"] as? String)
                ?? String(folderName.dropLast(4))
            let version = (plist?["CFBundleShortVersionString"] as? String) ?? (plist?["CFBundleVersion"] as? String)
            let bundleID = plist?["CFBundleIdentifier"] as? String

            var baseName = sanitize(displayName)
            if let version = version, !version.isEmpty {
                baseName += "_" + sanitize(version)
            }
            let outputURL = outputDirectory.appendingPathComponent(baseName).appendingPathExtension("ipa")
            if fileManager.fileExists(atPath: outputURL.path) {
                try fileManager.removeItem(at: outputURL)
            }

            let foundExecutable = try writeIPA(
                root: root,
                folderName: folderName,
                executable: executable,
                entries: entries,
                latest: latest,
                tar: tar,
                to: outputURL
            )

            if plist == nil {
                warnings.append("\(displayName): the app's Info.plist is missing or unreadable, so the .ipa probably won't install.")
            } else if !foundExecutable {
                warnings.append("\(displayName): the app's main program is missing, so the .ipa probably won't install.")
            }
            if root.hasPrefix("var/jb/") {
                warnings.append("\(displayName) was made for a rootless jailbreak. It may rely on jailbreak files and might not open without one.")
            }

            apps.append(ConvertedApp(
                name: displayName,
                bundleID: bundleID,
                version: version,
                ipaURL: outputURL,
                sizeBytes: fileSize(outputURL)
            ))
        }

        let hasOutsideFiles = entries.contains { entry in
            (entry.kind == .file || entry.kind == .symlink)
                && !appRoots.contains(where: { entry.path == $0 || entry.path.hasPrefix($0 + "/") })
        }
        if hasOutsideFiles {
            warnings.append("The package also installs files outside the app, such as helpers, tweaks or settings. These can't go into an .ipa, so some features may not work.")
        }

        return ConversionResult(debInfo: info, apps: apps, warnings: warnings)
    }

    static func listConverted() -> [LibraryFile] {
        let keys: [URLResourceKey] = [.fileSizeKey, .contentModificationDateKey]
        guard let urls = try? FileManager.default.contentsOfDirectory(
            at: outputDirectory,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles]
        ) else { return [] }

        return urls
            .filter { $0.pathExtension.lowercased() == "ipa" }
            .map { url in
                let values = try? url.resourceValues(forKeys: Set(keys))
                return LibraryFile(
                    url: url,
                    size: Int64(values?.fileSize ?? 0),
                    modified: values?.contentModificationDate ?? .distantPast
                )
            }
            .sorted { $0.modified > $1.modified }
    }

    // MARK: - Helpers

    private static func writeIPA(
        root: String,
        folderName: String,
        executable: String?,
        entries: [TarEntry],
        latest: [String: Int],
        tar: Data,
        to url: URL
    ) throws -> Bool {
        let zip = try ZipWriter(url: url)
        var finished = false
        defer {
            if !finished {
                zip.abort()
                try? FileManager.default.removeItem(at: url)
            }
        }

        let appPrefix = "Payload/" + folderName
        try zip.addDirectory("Payload/", date: Date())
        try zip.addDirectory(appPrefix + "/", date: Date())

        var foundExecutable = false

        for entry in entries where latest[entry.path] == entry.index {
            guard entry.path.hasPrefix(root + "/") else { continue }
            let relative = String(entry.path.dropFirst(root.count + 1))
            let zipPath = appPrefix + "/" + relative

            switch entry.kind {
            case .directory:
                try zip.addDirectory(zipPath + "/", date: entry.modified)

            case .file:
                var mode = entry.mode
                if relative == executable {
                    mode |= 0o755
                    foundExecutable = true
                }
                try zip.addFile(zipPath, data: tar.subdata(in: entry.dataRange), mode: mode, date: entry.modified)

            case .symlink:
                try zip.addSymlink(zipPath, target: entry.linkTarget, date: entry.modified)

            case .hardlink:
                guard let target = TarArchive.normalize(entry.linkTarget),
                      let targetIndex = latest[target],
                      entries[targetIndex].kind == .file
                else { continue }
                var mode = entries[targetIndex].mode
                if relative == executable {
                    mode |= 0o755
                    foundExecutable = true
                }
                try zip.addFile(zipPath, data: tar.subdata(in: entries[targetIndex].dataRange), mode: mode, date: entry.modified)

            case .other:
                continue
            }
        }

        try zip.finish()
        finished = true
        return foundExecutable
    }

    private static func readPlist(at path: String, entries: [TarEntry], latest: [String: Int], tar: Data) -> [String: Any]? {
        guard let index = latest[path] else { return nil }
        var entry = entries[index]
        if entry.kind == .hardlink,
           let target = TarArchive.normalize(entry.linkTarget),
           let targetIndex = latest[target] {
            entry = entries[targetIndex]
        }
        guard entry.kind == .file else { return nil }
        let data = tar.subdata(in: entry.dataRange)
        return (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) as? [String: Any]
    }

    private static func parseControl(_ text: String) -> DebInfo {
        var info = DebInfo()
        for line in text.split(whereSeparator: \.isNewline) {
            guard !line.hasPrefix(" "), !line.hasPrefix("\t"), let colon = line.firstIndex(of: ":") else { continue }
            let key = line[..<colon].trimmingCharacters(in: .whitespaces).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
            switch key {
            case "package": info.package = value
            case "name": info.name = value
            case "version": info.version = value
            case "architecture": info.architecture = value
            default: break
            }
        }
        return info
    }

    private static func sanitize(_ text: String) -> String {
        let unsafe = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        let cleaned = text.components(separatedBy: unsafe).joined(separator: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "App" : cleaned
    }

    private static func fileSize(_ url: URL) -> Int64 {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        return Int64(values?.fileSize ?? 0)
    }
}
