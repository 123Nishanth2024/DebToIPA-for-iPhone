import SwiftUI

@main
struct DebToIPAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
