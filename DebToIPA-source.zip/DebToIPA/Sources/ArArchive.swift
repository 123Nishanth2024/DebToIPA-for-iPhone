import Foundation

/// One file inside the outer `ar` container of a .deb package.
struct ArMember {
    let name: String
    let data: Data
}

/// Reads the `ar` container format used by .deb packages.
enum ArArchive {
    static func parse(_ data: Data) throws -> [ArMember] {
        let magic = Array("!<arch>\n".utf8)
        guard data.count >= 8, Array(data.prefix(8)) == magic else {
            throw ConversionError.notADeb
        }

        var members: [ArMember] = []
        var pos = data.startIndex + 8

        while pos + 60 <= data.endIndex {
            let header = data.subdata(in: pos..<(pos + 60))
            guard header[58] == 0x60, header[59] == 0x0A else {
                throw ConversionError.corrupt("bad package header")
            }

            var name = field(header, 0, 16)
            guard let size = Int(field(header, 48, 10)), size >= 0 else {
                throw ConversionError.corrupt("bad member size")
            }

            var contentStart = pos + 60
            var contentSize = size

            // BSD style long names: "#1/<length>", name stored before the content.
            if name.hasPrefix("#1/"), let nameLength = Int(name.dropFirst(3)) {
                guard nameLength <= size, contentStart + nameLength <= data.endIndex else {
                    throw ConversionError.corrupt("bad member name")
                }
                name = String(decoding: data[contentStart..<(contentStart + nameLength)], as: UTF8.self)
                    .trimmingCharacters(in: CharacterSet(charactersIn: "\0"))
                contentStart += nameLength
                contentSize -= nameLength
            }

            if name.hasSuffix("/") {
                name.removeLast()
            }

            guard contentStart + contentSize <= data.endIndex else {
                throw ConversionError.corrupt("package is truncated")
            }

            members.append(ArMember(name: name, data: data[contentStart..<(contentStart + contentSize)]))

            pos = contentStart + contentSize
            if size % 2 == 1 {
                pos += 1
            }
        }

        return members
    }

    private static func field(_ header: Data, _ start: Int, _ length: Int) -> String {
        String(decoding: header[start..<(start + length)], as: UTF8.self)
            .trimmingCharacters(in: .whitespaces)
    }
}
