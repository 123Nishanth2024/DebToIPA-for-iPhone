import Foundation

enum ConversionError: LocalizedError {
    case notADeb
    case missingData
    case unsupportedCompression(String)
    case corrupt(String)
    case tweak
    case notIOS(architecture: String)
    case noApp
    case tooLarge
    case writeFailed

    var errorDescription: String? {
        switch self {
        case .notADeb:
            return "This file isn't a .deb package."
        case .missingData:
            return "This .deb package has no content to convert."
        case .unsupportedCompression(let format):
            var text = "This package is compressed with \(format), which this converter can't unpack yet. Supported formats are gzip, xz and uncompressed."
            if format.lowercased().contains("zstandard") {
                text += " Linux packages (for example from Ubuntu) often use this format and couldn't run on iOS anyway."
            }
            return text
        case .corrupt(let detail):
            return "The package seems damaged or incomplete (\(detail)). Try downloading it again."
        case .tweak:
            return "This is a tweak, not an app. Tweaks change other apps or the system and can't be turned into an .ipa."
        case .notIOS(let architecture):
            return "This package is built for \"\(architecture)\", not for iPhone or iPad, so it can't run on iOS."
        case .noApp:
            return "No app was found in this package. It may be a library, a command-line tool or a theme, which can't be turned into an .ipa."
        case .tooLarge:
            return "This app is too large to package (over 4 GB or more than 65,535 files)."
        case .writeFailed:
            return "The .ipa file couldn't be saved. Check that your device has enough free space."
        }
    }
}

extension Data {
    mutating func appendLE16(_ value: UInt16) {
        append(contentsOf: [UInt8(truncatingIfNeeded: value), UInt8(truncatingIfNeeded: value >> 8)])
    }

    mutating func appendLE32(_ value: UInt32) {
        append(contentsOf: [
            UInt8(truncatingIfNeeded: value),
            UInt8(truncatingIfNeeded: value >> 8),
            UInt8(truncatingIfNeeded: value >> 16),
            UInt8(truncatingIfNeeded: value >> 24),
        ])
    }
}
