import Compression
import Foundation

/// Writes a standard zip file (an .ipa is a zip with a Payload folder).
final class ZipWriter {
    private let handle: FileHandle
    private var offset: UInt64 = 0
    private var centralDirectory = Data()
    private var entryCount = 0
    private var closed = false

    init(url: URL) throws {
        guard FileManager.default.createFile(atPath: url.path, contents: nil) else {
            throw ConversionError.writeFailed
        }
        handle = try FileHandle(forWritingTo: url)
    }

    func addDirectory(_ path: String, date: Date) throws {
        let attributes = (UInt32(0o040755) << 16) | 0x10
        try addEntry(path: path, contents: Data(), uncompressedSize: 0, crc: 0, method: 0, externalAttributes: attributes, date: date)
    }

    func addSymlink(_ path: String, target: String, date: Date) throws {
        let data = Data(target.utf8)
        let attributes = UInt32(0o120777) << 16
        try addEntry(path: path, contents: data, uncompressedSize: data.count, crc: CRC32.checksum(data), method: 0, externalAttributes: attributes, date: date)
    }

    func addFile(_ path: String, data: Data, mode: UInt32, date: Date) throws {
        let permissions: UInt32 = (mode & 0o7777) == 0 ? 0o644 : (mode & 0o7777)
        let crc = CRC32.checksum(data)
        var method: UInt16 = 0
        var contents = data
        if data.count > 64, let deflated = Deflate.compress(data), deflated.count < data.count {
            contents = deflated
            method = 8
        }
        let attributes = (UInt32(0o100000) | permissions) << 16
        try addEntry(path: path, contents: contents, uncompressedSize: data.count, crc: crc, method: method, externalAttributes: attributes, date: date)
    }

    func finish() throws {
        let directoryOffset = offset
        let directorySize = centralDirectory.count
        try write(centralDirectory)
        guard directoryOffset <= 0xFFFF_FFFF else { throw ConversionError.tooLarge }

        var end = Data()
        end.appendLE32(0x0605_4B50)
        end.appendLE16(0)
        end.appendLE16(0)
        end.appendLE16(UInt16(entryCount))
        end.appendLE16(UInt16(entryCount))
        end.appendLE32(UInt32(directorySize))
        end.appendLE32(UInt32(directoryOffset))
        end.appendLE16(0)
        try write(end)

        try handle.close()
        closed = true
    }

    func abort() {
        guard !closed else { return }
        try? handle.close()
        closed = true
    }

    private func addEntry(path: String, contents: Data, uncompressedSize: Int, crc: UInt32, method: UInt16, externalAttributes: UInt32, date: Date) throws {
        let name = Data(path.utf8)
        guard name.count <= 0xFFFF else { throw ConversionError.corrupt("file name too long") }
        guard entryCount < 0xFFFF,
              contents.count <= 0xFFFF_FFFF,
              uncompressedSize <= 0xFFFF_FFFF,
              offset <= 0xFFFF_FFFF
        else { throw ConversionError.tooLarge }

        let (dosTime, dosDate) = ZipWriter.dosDateTime(date)
        let localHeaderOffset = UInt32(offset)

        var local = Data()
        local.appendLE32(0x0403_4B50)
        local.appendLE16(20)          // version needed
        local.appendLE16(0x0800)      // UTF-8 names
        local.appendLE16(method)
        local.appendLE16(dosTime)
        local.appendLE16(dosDate)
        local.appendLE32(crc)
        local.appendLE32(UInt32(contents.count))
        local.appendLE32(UInt32(uncompressedSize))
        local.appendLE16(UInt16(name.count))
        local.appendLE16(0)           // extra length
        local.append(name)
        try write(local)
        try write(contents)

        var central = Data()
        central.appendLE32(0x0201_4B50)
        central.appendLE16(0x031E)    // made by Unix, zip 3.0
        central.appendLE16(20)
        central.appendLE16(0x0800)
        central.appendLE16(method)
        central.appendLE16(dosTime)
        central.appendLE16(dosDate)
        central.appendLE32(crc)
        central.appendLE32(UInt32(contents.count))
        central.appendLE32(UInt32(uncompressedSize))
        central.appendLE16(UInt16(name.count))
        central.appendLE16(0)         // extra length
        central.appendLE16(0)         // comment length
        central.appendLE16(0)         // disk number
        central.appendLE16(0)         // internal attributes
        central.appendLE32(externalAttributes)
        central.appendLE32(localHeaderOffset)
        central.append(name)
        centralDirectory.append(central)

        entryCount += 1
    }

    private func write(_ data: Data) throws {
        guard !data.isEmpty else { return }
        try handle.write(contentsOf: data)
        offset += UInt64(data.count)
    }

    private static func dosDateTime(_ date: Date) -> (UInt16, UInt16) {
        let calendar = Calendar(identifier: .gregorian)
        let c = calendar.dateComponents(in: TimeZone.current, from: date)
        let year = max(1980, min(2107, c.year ?? 1980))
        let hour = c.hour ?? 0
        let minute = c.minute ?? 0
        let second = c.second ?? 0
        let month = c.month ?? 1
        let day = c.day ?? 1
        let time = UInt16(truncatingIfNeeded: (hour << 11) | (minute << 5) | (second / 2))
        let dosDate = UInt16(truncatingIfNeeded: ((year - 1980) << 9) | (month << 5) | day)
        return (time, dosDate)
    }
}

enum CRC32 {
    private static let table: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 {
            c = (c & 1) != 0 ? (0xEDB8_8320 ^ (c >> 1)) : (c >> 1)
        }
        return c
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFF_FFFF
        table.withUnsafeBufferPointer { lookup in
            data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
                for byte in raw {
                    crc = lookup[Int((crc ^ UInt32(byte)) & 0xFF)] ^ (crc >> 8)
                }
            }
        }
        return crc ^ 0xFFFF_FFFF
    }
}

enum Deflate {
    /// Raw DEFLATE, exactly what zip method 8 expects. Returns nil if it doesn't shrink the data.
    static func compress(_ data: Data) -> Data? {
        guard !data.isEmpty else { return nil }
        let capacity = data.count
        let destination = UnsafeMutablePointer<UInt8>.allocate(capacity: capacity)
        defer { destination.deallocate() }

        let written = data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) -> Int in
            guard let source = raw.bindMemory(to: UInt8.self).baseAddress else { return 0 }
            return compression_encode_buffer(destination, capacity, source, raw.count, nil, COMPRESSION_ZLIB)
        }
        guard written > 0 else { return nil }
        return Data(bytes: destination, count: written)
    }
}
