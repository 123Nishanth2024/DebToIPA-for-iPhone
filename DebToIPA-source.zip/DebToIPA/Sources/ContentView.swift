import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var model = ConverterModel()
    @State private var showImporter = false
    @State private var shareItem: ShareItem?

    private var allowedTypes: [UTType] {
        var types: [UTType] = []
        if let deb = UTType(filenameExtension: "deb") {
            types.append(deb)
        }
        types.append(.data)
        return types
    }

    var body: some View {
        NavigationView {
            List {
                chooseSection
                if model.isWorking {
                    workingSection
                }
                if let message = model.errorMessage {
                    errorSection(message)
                }
                if let result = model.lastResult {
                    resultSection(result)
                }
                librarySection
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Deb to IPA")
        }
        .navigationViewStyle(.stack)
        .fileImporter(isPresented: $showImporter, allowedContentTypes: allowedTypes, allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first {
                    model.convert(url)
                }
            case .failure(let error):
                model.errorMessage = error.localizedDescription
            }
        }
        .onOpenURL { url in
            model.convert(url)
        }
        .sheet(item: $shareItem) { item in
            ShareSheet(items: [item.url])
        }
        .onAppear {
            model.refreshLibrary()
        }
    }

    // MARK: - Sections

    private var chooseSection: some View {
        Section {
            Button {
                showImporter = true
            } label: {
                Label("Choose a .deb file", systemImage: "doc.badge.plus")
            }
            .disabled(model.isWorking)
        } footer: {
            Text("Works with jailbreak packages that contain an app. Tweaks and Linux packages can't be converted. The new .ipa is unsigned, so install it with TrollStore.")
        }
    }

    private var workingSection: some View {
        Section {
            HStack(spacing: 12) {
                ProgressView()
                VStack(alignment: .leading, spacing: 2) {
                    Text("Converting…")
                    Text(model.currentFileName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
            }
            .padding(.vertical, 4)
        }
    }

    private func errorSection(_ message: String) -> some View {
        Section(header: Text("Couldn't convert")) {
            Label {
                Text(message)
            } icon: {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
            }
        }
    }

    private func resultSection(_ result: ConversionResult) -> some View {
        Section(header: Text("Ready to install")) {
            ForEach(result.apps) { app in
                VStack(alignment: .leading, spacing: 6) {
                    Text(app.name)
                        .font(.headline)
                    Text(details(for: app))
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Button {
                        shareItem = ShareItem(url: app.ipaURL)
                    } label: {
                        Label("Install with TrollStore…", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.top, 2)
                }
                .padding(.vertical, 4)
            }
            ForEach(result.warnings, id: \.self) { warning in
                Label {
                    Text(warning)
                        .font(.footnote)
                } icon: {
                    Image(systemName: "info.circle")
                        .foregroundColor(.secondary)
                }
            }
        }
    }

    private var librarySection: some View {
        Section(header: Text("Converted files")) {
            if model.library.isEmpty {
                Text("No converted files yet.")
                    .foregroundColor(.secondary)
            } else {
                ForEach(model.library) { file in
                    Button {
                        shareItem = ShareItem(url: file.url)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "shippingbox")
                                .foregroundColor(.secondary)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(file.name)
                                    .foregroundColor(.primary)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Text(subtitle(for: file))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "square.and.arrow.up")
                                .foregroundColor(.accentColor)
                                .accessibilityLabel("Share")
                        }
                    }
                }
                .onDelete { offsets in
                    model.deleteFiles(at: offsets)
                }
            }
        }
    }

    // MARK: - Formatting

    private func details(for app: ConvertedApp) -> String {
        var parts: [String] = []
        if let bundleID = app.bundleID { parts.append(bundleID) }
        if let version = app.version { parts.append("Version \(version)") }
        parts.append(ByteCountFormatter.string(fromByteCount: app.sizeBytes, countStyle: .file))
        return parts.joined(separator: " · ")
    }

    private func subtitle(for file: LibraryFile) -> String {
        let size = ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file)
        let date = DateFormatter.localizedString(from: file.modified, dateStyle: .medium, timeStyle: .short)
        return "\(size) · \(date)"
    }
}
