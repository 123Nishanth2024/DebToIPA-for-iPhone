import Foundation

@MainActor
final class ConverterModel: ObservableObject {
    @Published var isWorking = false
    @Published var currentFileName = ""
    @Published var errorMessage: String?
    @Published var lastResult: ConversionResult?
    @Published var library: [LibraryFile] = []

    func convert(_ url: URL) {
        guard !isWorking else { return }
        isWorking = true
        errorMessage = nil
        lastResult = nil
        currentFileName = url.lastPathComponent

        Task.detached(priority: .userInitiated) {
            let outcome = DebConverter.convertFile(at: url)
            await self.finish(outcome)
        }
    }

    func refreshLibrary() {
        library = DebConverter.listConverted()
    }

    func deleteFiles(at offsets: IndexSet) {
        let urls = offsets.map { library[$0].url }
        for url in urls {
            try? FileManager.default.removeItem(at: url)
        }
        if var result = lastResult {
            result.apps.removeAll { urls.contains($0.ipaURL) }
            lastResult = result.apps.isEmpty ? nil : result
        }
        refreshLibrary()
    }

    private func finish(_ outcome: Result<ConversionResult, Error>) {
        isWorking = false
        switch outcome {
        case .success(let result):
            lastResult = result
        case .failure(let error):
            errorMessage = error.localizedDescription
        }
        refreshLibrary()
    }
}
