import Foundation

struct TarEntry {
    enum Kind {
        case file, directory, symlink, hardlink, other
    }

    let index: Int
    /// Normalized path without a leading "./" or "/".
    let path: String
    let kind: Kind
    let mode: UInt32
    let modified: Date
    let linkTarget: String
    /// Range of the file's bytes inside the tar data (absolute indices).
    let dataRange: Range<Int>
}

/// Reads ustar, GNU and PAX tar archives.
enum TarArchive {
    static func parse(_ data: Data) throws -> [TarEntry] {
        var entries: [TarEntry] = []
        let end = data.endIndex
        var offset = data.startIndex

        var gnuLongName: String?
        var gnuLongLink: String?
        var pax: [String: String] = [:]

        let metaFlags: [UInt8] = [UInt8(ascii: "L"), UInt8(ascii: "K"), UInt8(ascii: "x"), UInt8(ascii: "g")]

        while offset + 512 <= end {
            let header = data.subdata(in: offset..<(offset + 512))
            if header.allSatisfy({ $0 == 0 }) {
                break
            }
            guard verifyChecksum(header) else {
                throw ConversionError.corrupt("bad archive header")
            }

            let typeflag = header[156]
            let isMeta = metaFlags.contains(typeflag)

            var size = parseNumber(header, 124, 12)
            if !isMeta, let paxSize = pax["size"], let value = Int(paxSize) {
                size = value
            }

            let contentStart = offset + 512
            guard size >= 0, contentStart + size <= end else {
                throw ConversionError.corrupt("archive is truncated")
            }
            let contentRange = contentStart..<(contentStart + size)
            offset = contentStart + ((size + 511) / 512) * 512

            switch typeflag {
            case UInt8(ascii: "L"):
                gnuLongName = cString(data.subdata(in: contentRange))
                continue
            case UInt8(ascii: "K"):
                gnuLongLink = cString(data.subdata(in: contentRange))
                continue
            case UInt8(ascii: "x"):
                pax = parsePax(data.subdata(in: contentRange))
                continue
            case UInt8(ascii: "g"):
                continue
            default:
                break
            }

            var name: String
            if let paxPath = pax["path"] {
                name = paxPath
            } else if let longName = gnuLongName {
                name = longName
            } else {
                name = cString(header[0..<100])
                if header[257..<263] == Data("ustar\0".utf8) {
                    let prefix = cString(header[345..<500])
                    if !prefix.isEmpty {
                        name = prefix + "/" + name
                    }
                }
            }

            let linkTarget = pax["linkpath"] ?? gnuLongLink ?? cString(header[157..<257])
            let mode = UInt32(truncatingIfNeeded: parseNumber(header, 100, 8)) & 0o7777
            let seconds = Double(pax["mtime"] ?? "") ?? Double(parseNumber(header, 136, 12))

            var kind: TarEntry.Kind
            switch typeflag {
            case 0, UInt8(ascii: "0"), UInt8(ascii: "7"):
                kind = .file
            case UInt8(ascii: "1"):
                kind = .hardlink
            case UInt8(ascii: "2"):
                kind = .symlink
            case UInt8(ascii: "5"):
                kind = .directory
            default:
                kind = .other
            }
            if kind == .file && name.hasSuffix("/") {
                kind = .directory
            }

            pax = [:]
            gnuLongName = nil
            gnuLongLink = nil

            guard let path = normalize(name), !path.isEmpty else {
                continue
            }

            entries.append(TarEntry(
                index: entries.count,
                path: path,
                kind: kind,
                mode: mode,
                modified: Date(timeIntervalSince1970: seconds),
                linkTarget: linkTarget,
                dataRange: contentRange
            ))
        }

        return entries
    }

    /// Removes "." parts and leading slashes. Returns nil for paths that try to escape with "..".
    static func normalize(_ path: String) -> String? {
        var parts: [String] = []
        for part in path.split(separator: "/") {
            if part == "." || part.isEmpty { continue }
            if part == ".." { return nil }
            parts.append(String(part))
        }
        return parts.joined(separator: "/")
    }

    private static func verifyChecksum(_ header: Data) -> Bool {
        let stored = parseNumber(header, 148, 8)
        var unsigned = 0
        var signed = 0
        for i in 0..<512 {
            let byte: UInt8 = (148..<156).contains(i) ? 32 : header[i]
            unsigned += Int(byte)
            signed += Int(Int8(bitPattern: byte))
        }
        return stored == unsigned || stored == signed
    }

    /// Parses an octal field, or a base-256 field when the high bit is set.
    private static func parseNumber(_ header: Data, _ start: Int, _ length: Int) -> Int {
        let bytes = [UInt8](header[start..<(start + length)])
        guard let first = bytes.first else { return 0 }

        if first & 0x80 != 0 {
            var value = Int(first & 0x7F)
            for byte in bytes.dropFirst() {
                value = (value << 8) | Int(byte)
            }
            return value
        }

        var value = 0
        var started = false
        for byte in bytes {
            if byte == 0 || byte == 32 {
                if started { break } else { continue }
            }
            guard byte >= 48 && byte <= 55 else { break }
            started = true
            value = value * 8 + Int(byte - 48)
        }
        return value
    }

    private static func cString(_ data: Data) -> String {
        let bytes = data.prefix { $0 != 0 }
        return String(data: bytes, encoding: .utf8) ?? String(decoding: bytes, as: UTF8.self)
    }

    private static func parsePax(_ data: Data) -> [String: String] {
        var result: [String: String] = [:]
        let bytes = [UInt8](data)
        var i = 0

        while i < bytes.count {
            var j = i
            while j < bytes.count && bytes[j] != 32 { j += 1 }
            guard j < bytes.count,
                  let length = Int(String(decoding: bytes[i..<j], as: UTF8.self)),
                  length > 0,
                  i + length <= bytes.count,
                  j + 1 <= i + length
            else { break }

            let recordEnd = i + length
            let record = bytes[(j + 1)..<recordEnd]
            if let equals = record.firstIndex(of: UInt8(ascii: "=")) {
                let key = String(decoding: bytes[(j + 1)..<equals], as: UTF8.self)
                var valueEnd = recordEnd
                if valueEnd > equals + 1 && bytes[valueEnd - 1] == 10 {
                    valueEnd -= 1
                }
                result[key] = String(decoding: bytes[(equals + 1)..<valueEnd], as: UTF8.self)
            }
            i = recordEnd
        }

        return result
    }
}
