import Compression
import Foundation

/// Unpacks the compressed tar archives inside a .deb package.
enum Decompressor {
    private static let maxOutputSize = 4_000_000_000

    static func decompress(_ data: Data, fileName: String) throws -> Data {
        let head = Array(data.prefix(6))

        if head.count >= 2, head[0] == 0x1F, head[1] == 0x8B {
            return try gunzip(data)
        }
        if head.count >= 6, head == [0xFD, 0x37, 0x7A, 0x58, 0x5A, 0x00] {
            return try stream(data, algorithm: COMPRESSION_LZMA, format: "xz")
        }
        if head.count >= 4, Array(head[0..<4]) == [0x28, 0xB5, 0x2F, 0xFD] {
            throw ConversionError.unsupportedCompression("Zstandard (.zst)")
        }
        if head.count >= 3, Array(head[0..<3]) == [0x42, 0x5A, 0x68] {
            throw ConversionError.unsupportedCompression("bzip2 (.bz2)")
        }
        if fileName.hasSuffix(".lzma") {
            throw ConversionError.unsupportedCompression("legacy LZMA (.lzma)")
        }
        if fileName.hasSuffix(".tar") || looksLikeTar(data) {
            return data
        }
        throw ConversionError.unsupportedCompression("an unknown format (\(fileName))")
    }

    private static func looksLikeTar(_ data: Data) -> Bool {
        let s = data.startIndex
        guard data.count >= 262 else { return false }
        return Array(data[(s + 257)..<(s + 262)]) == Array("ustar".utf8)
    }

    private static func gunzip(_ data: Data) throws -> Data {
        let s = data.startIndex
        guard data.count >= 18, data[s + 2] == 8 else {
            throw ConversionError.corrupt("unsupported gzip data")
        }
        let flags = data[s + 3]
        var pos = s + 10

        if flags & 0x04 != 0 {
            guard pos + 2 <= data.endIndex else { throw ConversionError.corrupt("bad gzip header") }
            let extraLength = Int(data[pos]) | (Int(data[pos + 1]) << 8)
            pos += 2 + extraLength
        }
        if flags & 0x08 != 0 {
            while pos < data.endIndex && data[pos] != 0 { pos += 1 }
            pos += 1
        }
        if flags & 0x10 != 0 {
            while pos < data.endIndex && data[pos] != 0 { pos += 1 }
            pos += 1
        }
        if flags & 0x02 != 0 {
            pos += 2
        }

        let end = data.endIndex - 8
        guard pos < end else { throw ConversionError.corrupt("bad gzip header") }
        return try stream(data[pos..<end], algorithm: COMPRESSION_ZLIB, format: "gzip")
    }

    private static func stream(_ input: Data, algorithm: compression_algorithm, format: String) throws -> Data {
        let bufferSize = 1 << 20
        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: bufferSize)
        defer { buffer.deallocate() }

        let streamPointer = UnsafeMutablePointer<compression_stream>.allocate(capacity: 1)
        defer { streamPointer.deallocate() }

        guard compression_stream_init(streamPointer, COMPRESSION_STREAM_DECODE, algorithm) == COMPRESSION_STATUS_OK else {
            throw ConversionError.corrupt("couldn't start \(format) decoder")
        }
        defer { compression_stream_destroy(streamPointer) }

        var output = Data()

        try input.withUnsafeBytes { (raw: UnsafeRawBufferPointer) throws -> Void in
            guard let source = raw.bindMemory(to: UInt8.self).baseAddress else {
                throw ConversionError.corrupt("empty \(format) data")
            }
            streamPointer.pointee.src_ptr = source
            streamPointer.pointee.src_size = raw.count
            streamPointer.pointee.dst_ptr = buffer
            streamPointer.pointee.dst_size = bufferSize

            while true {
                let status = compression_stream_process(streamPointer, Int32(COMPRESSION_STREAM_FINALIZE.rawValue))
                switch status {
                case COMPRESSION_STATUS_OK, COMPRESSION_STATUS_END:
                    let produced = bufferSize - streamPointer.pointee.dst_size
                    if produced > 0 {
                        output.append(buffer, count: produced)
                        if output.count > maxOutputSize {
                            throw ConversionError.tooLarge
                        }
                    }
                    if status == COMPRESSION_STATUS_END {
                        return
                    }
                    if produced == 0 && streamPointer.pointee.src_size == 0 {
                        throw ConversionError.corrupt("\(format) data ended early")
                    }
                    streamPointer.pointee.dst_ptr = buffer
                    streamPointer.pointee.dst_size = bufferSize
                default:
                    throw ConversionError.corrupt("\(format) data is invalid")
                }
            }
        }

        return output
    }
}
